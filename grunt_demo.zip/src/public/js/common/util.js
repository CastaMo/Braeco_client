!function(a,b){"function"==typeof define&&define.amd?define([],b):"undefined"!=typeof module&&module.exports?module.exports=b():a.ReconnectingWebSocket=b()}(this,function(){function a(b,c,d){function l(a,b){var c=document.createEvent("CustomEvent");return c.initCustomEvent(a,!1,!1,b),c}var e={debug:!1,automaticOpen:!0,reconnectInterval:1e3,maxReconnectInterval:3e4,reconnectDecay:1.5,timeoutInterval:2e3};d||(d={});for(var f in e)this[f]="undefined"!=typeof d[f]?d[f]:e[f];this.url=b,this.reconnectAttempts=0,this.readyState=WebSocket.CONNECTING,this.protocol=null;var h,g=this,i=!1,j=!1,k=document.createElement("div");k.addEventListener("open",function(a){g.onopen(a)}),k.addEventListener("close",function(a){g.onclose(a)}),k.addEventListener("connecting",function(a){g.onconnecting(a)}),k.addEventListener("message",function(a){g.onmessage(a)}),k.addEventListener("error",function(a){g.onerror(a)}),this.addEventListener=k.addEventListener.bind(k),this.removeEventListener=k.removeEventListener.bind(k),this.dispatchEvent=k.dispatchEvent.bind(k),this.open=function(b){h=new WebSocket(g.url,c||[]),b||k.dispatchEvent(l("connecting")),(g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","attempt-connect",g.url);var d=h,e=setTimeout(function(){(g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","connection-timeout",g.url),j=!0,d.close(),j=!1},g.timeoutInterval);h.onopen=function(){clearTimeout(e),(g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","onopen",g.url),g.protocol=h.protocol,g.readyState=WebSocket.OPEN,g.reconnectAttempts=0;var d=l("open");d.isReconnect=b,b=!1,k.dispatchEvent(d)},h.onclose=function(c){if(clearTimeout(e),h=null,i)g.readyState=WebSocket.CLOSED,k.dispatchEvent(l("close"));else{g.readyState=WebSocket.CONNECTING;var d=l("connecting");d.code=c.code,d.reason=c.reason,d.wasClean=c.wasClean,k.dispatchEvent(d),b||j||((g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","onclose",g.url),k.dispatchEvent(l("close")));var e=g.reconnectInterval*Math.pow(g.reconnectDecay,g.reconnectAttempts);setTimeout(function(){g.reconnectAttempts++,g.open(!0)},e>g.maxReconnectInterval?g.maxReconnectInterval:e)}},h.onmessage=function(b){(g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","onmessage",g.url,b.data);var c=l("message");c.data=b.data,k.dispatchEvent(c)},h.onerror=function(b){(g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","onerror",g.url,b),k.dispatchEvent(l("error"))}},1==this.automaticOpen&&this.open(!1),this.send=function(b){if(h)return(g.debug||a.debugAll)&&console.debug("ReconnectingWebSocket","send",g.url,b),h.send(b);throw"INVALID_STATE_ERR : Pausing to reconnect websocket"},this.close=function(a,b){"undefined"==typeof a&&(a=1e3),i=!0,h&&h.close(a,b)},this.refresh=function(){h&&h.close()}}return a.prototype.onopen=function(){},a.prototype.onclose=function(){},a.prototype.onconnecting=function(){},a.prototype.onmessage=function(){},a.prototype.onerror=function(){},a.debugAll=!1,a.CONNECTING=WebSocket.CONNECTING,a.OPEN=WebSocket.OPEN,a.CLOSING=WebSocket.CLOSING,a.CLOSED=WebSocket.CLOSED,a});
;var util = function(doc) {
	'use strict';
	var addListener = null,
		removeListener = null,
		hasClass,
		addClass,
		removeClass,
		ajax,
		getElementsByClassName,
		isPhone,
		hidePhone,
		query,
		querys,
		remove,
		append,
		prepend,
		toggleClass,
		getObjectURL,
		is,
		deepCopy;
	if (typeof window.addEventListener === 'function') {
		addListener = function(el, type, fn) {
			el.addEventListener(type, fn, false);
		};
		removeListener = function(el, type, fn) {
			el.removeEventListener(type, fn, false);
		};
	} else if (typeof document.attachEvent === 'function') {  //'IE'
		addListener = function(el, type, fn) {
			el.attachEvent('on'+type, fn);
		};
		removeListener = function(el, type, fn) {
			el.detachEvent('on'+type, fn);
		};
	} else {
		addListener = function(el, type, fn) {
			el['on'+type] = fn;
		};
		removeListener = function(el, type, fn) {
			el['on'+type] = null;
		};
	}

	hasClass = function(ele, cls) {
		var className, reg;
		reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
		className = ele.getAttribute("class") ? ele.className : "";
		return reg.test(className);
	};

	addClass = function(ele, cls) {
		if (!ele || hasClass(ele, cls)) {
			return (ele.className ? ele.className : "");
		}
		if (ele.className) {
			return (ele.className += ' ' + cls);
		} else {
			return (ele.className = cls);
		}
	};

	removeClass = function(ele, cls) {
		if (!ele) {
			return ele.className ? ele.className : "";
		}
		var reg = new RegExp("(\\s|^)" + cls + "(\\s|$)");
		return (ele.className = ele.className.replace(reg, " ").replace(/(^\s*)|(\s*$)/g, ""));
	}

	function callback(xhr, success) {
		if (xhr.readyState === 4) {
			if (xhr.status === 200) {
				if (typeof success === "function") {
					var result = xhr.responseText;
					success(result);
				}
			}
		}
	}

	ajax = function(options) {
		var xhr;
		if (window.XMLHttpRequest) {
			xhr = new XMLHttpRequest();
		} else {	//for IE6
			xhr = new ActiveXObject('Microsoft.XMLHTTP');
		}
		xhr.onreadystatechange = function() {
			callback(xhr, options.success);
		}
		xhr.open(options.type, options.url, options.async);
		if (options.type.toUpperCase() === "POST") {
			xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		}
		if (typeof options.data !== "undefined") {
			xhr.send(options.data);
		} else {
			xhr.send();
		}
		return xhr;
	}

	getElementsByClassName = function(tagName, className) {
		var result = [];
		var allTag = document.getElementsByTagName(tagName);
		for (var i = 0, len_ = allTag.length; i < len_; i++) {
			if (hasClass(allTag[i], className)) {
				result.push(allTag[i]);
			}
		}
		return result;
	}

	isPhone = function (aPhone) {
		return RegExp(/^(0|86|17951)?(13[0-9]|15[012356789]|18[0-9]|14[57])[0-9]{8}$/).test(aPhone);
    }

    hidePhone = function(number) {
    	return number.substr(0, 3)+"****"+number.substr(7, 4);
    }

    query = function(string, parentNode) {
    	if (parentNode) {
    		return parentNode.querySelector(string);
    	} else {
    		return document.querySelector(string);
    	}
    }

    querys = function(string, parentNode) {
    	if (parentNode) {
    		return parentNode.querySelectorAll(string);
    	} else {
    		return document.querySelectorAll(string);
    	}
    }

    remove = function(childNode) {
    	var parentNode = childNode.parentNode;
    	return parentNode.removeChild(childNode);
    }

    append = function(parentNode, childNode) {
    	if (typeof childNode === "string") {
    		var previousHTML = parentNode.innerHTML;
    		return parentNode.innerHTML = previousHTML + childNode;
    	} else {
    		return parentNode.appendChild(childNode);
    	}
    }

    prepend = function(parentNode, childNode) {
    	if (typeof childNode === "string") {
    		var previousHTML = parentNode.innerHTML;
    		return parentNode.innerHTML = childNode + previousHTML;
    	} else {
    		var reforeNode = parentNode.children[0];
    		parentNode.insertBefore(childNode, reforeNode);
    	}
    }

    toggleClass = function(ele, cls) {
    	if (hasClass(ele, cls)) {
    		return removeClass(ele, cls);
    	} else {
    		return addClass(ele, cls);
    	}
    }

    getObjectURL = function(file) {
    	var url = null;   
	    if (window.createObjectURL !== undefined) { // basic  
	        url = window.createObjectURL(file);  
	    } else if (window.URL !== undefined) { // mozilla(firefox)  
	        url = window.URL.createObjectURL(file);  
	    } else if (window.webkitURL !== undefined) { // webkit or chrome  
	        url = window.webkitURL.createObjectURL(file);  
	    }  
	    return url;
    }

    is = function(obj, type) {
    	var toString = Object.prototype.toString, undefined;
    	return (type === 'Null' && obj == null) ||
    		(type == "Undefined" && Object === undefined) ||
    		toString.call(obj).slice(8, -1) === type;
    }

    deepCopy = function(oldObj, newObj) {
    	for (var key in oldObj) {
	        var copy = oldObj[key];
	        if (oldObj === copy) continue; //如window.window === window，会陷入死循环，需要处理一下
	        if (is(copy, "Object")) {
	            newObj[key] = deepCopy(copy, newObj[key] || {});
	        } else if (is(copy, "Array")) {
	            newObj[key] = []
	            newObj[key] = deepCopy(copy, newObj[key] || []);
	        } else {
	            newObj[key] = copy;
	        }
	    }
	    return newObj;
    }

	return {
		addListener:addListener,
		removeListener:removeListener,
		hasClass:hasClass,
		addClass:addClass,
		removeClass:removeClass,
		ajax:ajax,
		getElementsByClassName:getElementsByClassName,
		isPhone:isPhone,
		hidePhone:hidePhone,
		query:query,
		querys:querys,
		remove:remove,
		append:append,
		prepend:prepend,
		toggleClass:toggleClass,
		getObjectURL:getObjectURL,
		is:is,
		deepCopy:deepCopy
	}
}(document);
